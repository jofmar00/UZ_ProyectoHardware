
#ifndef SVC_SC
#define SVC_SC
#include <stdint.h>

/*** FUNCIONES ***/
uint32_t svc_SC_entrar(void);
void svc_SC_salir(void);
#endif