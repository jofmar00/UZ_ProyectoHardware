/*ARCHIVO DE DECLARACION DE TESTS DE LA COLA FIFO DE EVENTOS*/
#include "rt_fifo.h"

/*** FUNCIONES ***/
int test_fifo(void);
