/* *****************************************************************************
 * P.H.2024: TODO
 */
 
#ifndef HAL_GPIO
#define HAL_GPIO

#include "hal_gpio.h"
#endif